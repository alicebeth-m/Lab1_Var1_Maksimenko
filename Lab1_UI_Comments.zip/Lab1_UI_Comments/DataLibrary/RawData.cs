﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary
{
    public delegate double FRaw(double x);
    public enum FRawEnum
    {
        Linear, Cubic, Randomic
    }
    public class RawData
    {
        public double leftEnd { get; set; }
        public double rightEnd { get; set; }
        public int nRawNodes { get; set; }
        public bool gridType { get; set; }
        public FRaw fRaw { get; set; }
        public double[] RawNodes { get; set; }
        public double[] RawValues { get; set; }
        public string filename { get; set; }
        public RawData(string filename)
        {
            this.filename = filename;
        }
        public RawData(double leftEnd, double rightEnd, int nRawNodes, bool gridType, FRaw fRaw)
        {
            this.leftEnd = leftEnd;
            this.rightEnd = rightEnd;
            this.nRawNodes = nRawNodes;
            this.fRaw = fRaw;
            this.gridType = gridType;
        }

        public static double Linear(double x)
        { return x; }
        public static double Randomic(double x)
        {
            Random rand = new Random();
            return rand.NextDouble() * 99 + x;
        }
        public static double Cubic(double x)
        { return x * (x - 1) * (x - 2) + 2; }

        public void Save(string filename)
        {
            FileStream? f = null;
            try
            {
                f = new FileStream(filename, FileMode.Create);
                StreamWriter sw = new StreamWriter(f);
                sw.WriteLine($"{this.leftEnd}");
                sw.WriteLine($"{this.rightEnd}");
                sw.WriteLine($"{this.nRawNodes}");
                sw.WriteLine($"{this.gridType}");
                FRaw fRaw = this.fRaw;
                string? func = fRaw.Method.Name;
                sw.WriteLine($"{func}");
                for (var i = 0; i < this.nRawNodes; i++)
                {
                    sw.Write($"{this.RawNodes[i]} {this.RawValues[i]} ");
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (f != null)
                {
                    f.Close();
                }
            }
        }
        public static void Load(string filename, out RawData? rawData)
        {
            FileStream? f = null;
            try
            {
                f = new FileStream(filename, FileMode.Open);
                StreamReader sr = new StreamReader(f);
                double leftEnd = Convert.ToDouble(sr.ReadLine());
                double rightEnd = Convert.ToDouble(sr.ReadLine());
                int nRawNodes = Convert.ToInt32(sr.ReadLine());
                bool gridType = Convert.ToBoolean(sr.ReadLine());
                string? func = sr.ReadLine();
                FRaw function;
                switch (func)
                {
                    case "Linear":
                        function = Linear;
                        break;
                    case "Cubic":
                        function = Cubic;
                        break;
                    default:
                        function = Randomic;
                        break;
                }

                rawData = new RawData(leftEnd, rightEnd, nRawNodes, gridType, function);
                rawData.RawNodes = new Double[rawData.nRawNodes];
                rawData.RawValues = new Double[rawData.nRawNodes];
                string? nodes = sr.ReadLine();
                for (var i = 0; i < nRawNodes; i++)
                {
                    rawData.RawNodes[i] = Convert.ToDouble(nodes.Split(" ")[2 * i]);
                    rawData.RawValues[i] = Convert.ToDouble(nodes.Split(" ")[2 * i + 1]);
                }

                sr.Close();
            }
            catch (Exception ex)
            {
                rawData = null;
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (f != null)
                {
                    f.Close();
                }
            }
        }
    }
}
