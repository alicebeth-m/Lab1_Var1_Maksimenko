﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary
{
    public class SplineData
    {
        public int nGrid { get; set; }
        public RawData rawData { get; set; }
        public double leftDer { get; set; }
        public double rightDer { get; set; }
        public List<SplineDataItem> splineDataItems { get; set; }
        public double integralValue { get; set; }

        public SplineData(RawData rawData, double leftDer, double rightDer, int nGrid)
        {
            try
            {
                this.rawData = rawData;
                this.nGrid = nGrid;
                this.leftDer = leftDer;
                this.rightDer = rightDer;
                splineDataItems = new List<SplineDataItem>();
            }
            catch
            {
                throw new Exception();
            }
        }
        public void DoSplines()
        {
            // вызов функций MKL
            int error_code = 0;
            double[] grid = { rawData.leftEnd, rawData.rightEnd };
            double[] derivative = { leftDer, rightDer };
            double[] leftEnd = { rawData.leftEnd };
            double[] rightEnd = { rawData.rightEnd };
            double[] calcValues = new double[1 * 3 * nGrid];
            double[] cIntegrals = new double[1];
            double step = (rawData.rightEnd - rawData.leftEnd) / (nGrid - 1);

            make_spline(rawData.nRawNodes, grid, rawData.RawNodes, rawData.RawValues,
                rawData.gridType, nGrid, derivative,
                    leftEnd, rightEnd, cIntegrals, calcValues, ref error_code);
            if (error_code != 0)
            {
                throw new Exception($"MKL error_code = {error_code}\n");
            }
            for (int i = 0; i < nGrid; i++) splineDataItems.Add(new SplineDataItem(rawData.leftEnd + i * step, calcValues[i * 3], calcValues[i * 3 + 1], calcValues[i * 3 + 2]));

            integralValue = cIntegrals[0];
            [DllImport("C:\\Users\\user\\OneDrive\\Рабочий стол\\PRAK_lab_1\\Lab1_2023\\Lab1_UI_Comments\\x64\\Debug\\Dll1.dll", CallingConvention = CallingConvention.Cdecl)]
            static extern void make_spline(int nRawNodes, double[] grid, double[] RawNodes, double[] RawValues, bool gridType, int nGrid, double[] derivative, double[] leftEnd, double[] rightEnd, double[] cIntegrals, double[] calcValues, ref int error_code);
        }
    }
}
