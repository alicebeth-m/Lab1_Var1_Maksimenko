﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DataLibrary
{
    public class SplineDataItem
    {
        public double coord { get; set; }
        public double value { get; set; }
        public double firstDer { get; set; }
        public double secDer { get; set; }

        public SplineDataItem(double coords, double value, double firstDer, double secDer)
        {
            this.coord = coords;
            this.value = value;
            this.firstDer = firstDer;
            this.secDer = secDer;
        }
        public override string ToString()
        {
            return ToString("{0:F}");
        }

        public string ToString(string format)
        {
            string pointsString = "Coord =" + string.Format(format, coord) + "\nvalue ="
                + string.Format(format, value) + "\n1_Der =" + string.Format(format, firstDer)
                    + "\n2_Der =" + string.Format(format, secDer);
            //return string.Format(format, value, firstDer, secDer);
            //return $"Coords: [{coord.ToString(format)}]\nPoints: [{pointsString}]";
            return pointsString;
        }
    }
}
