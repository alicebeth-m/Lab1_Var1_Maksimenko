﻿// dllmain.cpp : Определяет точку входа для приложения DLL.
#include "pch.h"
#include "mkl.h"

BOOL APIENTRY DllMain(HMODULE hModule,
    DWORD ul_reason_for_call,
    LPVOID lpReserved
)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

extern "C" _declspec(dllexport) void make_spline(int nRawNodes, double* grid, double* RawNodes, double* RawValues, bool gridType, int nGrid, double* derivative, double* leftEnd, double* rightEnd, double* cIntegrals, double* calcValues, int& error_code)
{
    DFTaskPtr task;
    error_code = DF_STATUS_OK;
    if (gridType)
    {
        error_code = dfdNewTask1D(&task, nRawNodes, grid, DF_UNIFORM_PARTITION, 1, RawValues, DF_MATRIX_STORAGE_ROWS);
        if (error_code != DF_STATUS_OK)
        {
            return;
        }
    }
    else
    {
        error_code = dfdNewTask1D(&task, nRawNodes, RawNodes, DF_NON_UNIFORM_PARTITION, 1, RawValues, DF_MATRIX_STORAGE_ROWS);
        if (error_code != DF_STATUS_OK)
        {
            return;
        }
    }
    double* coeff = new double[4 * (nRawNodes - 1)];

    error_code = dfdEditPPSpline1D(task, DF_PP_CUBIC, DF_PP_NATURAL, DF_BC_1ST_LEFT_DER | DF_BC_1ST_RIGHT_DER, derivative, DF_NO_IC, NULL, coeff, DF_NO_HINT);
    if (error_code != DF_STATUS_OK)
    {
        return;
    }

    error_code = dfdConstruct1D(task, DF_PP_SPLINE, DF_METHOD_STD);
    if (error_code != DF_STATUS_OK)
    {
        return;
    }

    int ret[3] = { 1, 1, 1 };
    error_code = dfdInterpolate1D(task, DF_INTERP, DF_METHOD_PP, nGrid, grid, DF_UNIFORM_PARTITION, 3, ret, NULL, calcValues, DF_MATRIX_STORAGE_ROWS, NULL);
    if (error_code != DF_STATUS_OK)
    {
        return;
    }

    error_code = dfdIntegrate1D(task, DF_METHOD_PP, 1, leftEnd, DF_NON_UNIFORM_PARTITION, rightEnd, DF_NON_UNIFORM_PARTITION, NULL, NULL, cIntegrals, DF_MATRIX_STORAGE_ROWS);
    if (error_code != DF_STATUS_OK)
    {
        return;
    }
    error_code = dfDeleteTask(&task);
}
