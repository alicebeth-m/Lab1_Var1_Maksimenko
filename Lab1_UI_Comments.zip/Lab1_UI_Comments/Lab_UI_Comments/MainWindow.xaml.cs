﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataLibrary;
using Microsoft.Win32;

namespace Lab1_UI_Comments
{
    public partial class MainWindow : Window
    {
        ViewData viewData = new ViewData();
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = viewData;
            comboBox_Enum.ItemsSource = Enum.GetValues(typeof(DataLibrary.FRawEnum));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(viewData.ToString());
        }

        private void Button_Click_Save(object sender, RoutedEventArgs e)
        {
            SaveFileDialog files = new SaveFileDialog();
            if (files.ShowDialog() == true)
            {
                viewData.Save(files.FileName);
            }
        }
        private void button_execute_Click(object sender, RoutedEventArgs e)
        {
            list_box.Items.Clear();
            viewData.ExeSplines();
            string format = "{0:F}";
            for (int i = 0; i < viewData.rawData.nRawNodes; i++)
            {
                list_box.Items.Add($"Coord {string.Format(format, viewData.rawData.RawNodes[i])} value = {string.Format(format, viewData.rawData.RawValues[i])}");
            }
            spline_box.ItemsSource = viewData.splinesData.splineDataItems;
            text_integral.Text = string.Format(format, viewData.splinesData.integralValue);
        }

        private void Button_Click_Load(object sender, RoutedEventArgs e)
        {
            OpenFileDialog files = new OpenFileDialog();
            if (files.ShowDialog() == true)
            {
                list_box.Items.Clear();
                try
                {
                    viewData.Load(files.FileName);
                    viewData.ExeSplines_load();
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Ошибка: " + ex.Message + "\nДолжен быть:\nleftEnd\nrightEnd\nnRawNodes\ngridType\nfRaw\nCoord Value etc.");
                    // Очистка данных и списка
                    //viewData.rawData.Clear();
                    //viewData.splinesData.Clear();
                    list_box.Items.Clear();
                    spline_box.ItemsSource = null;
                    text_integral.Text = string.Empty;
                    // Возврат к начальному состоянию
                    return;
                }

                string format = "{0:F}";
                for (int i = 0; i < viewData.rawData.nRawNodes; i++)
                {
                    list_box.Items.Add($"Coord {string.Format(format, viewData.rawData.RawNodes[i])} value = {string.Format(format, viewData.rawData.RawValues[i])}");
                }
                spline_box.ItemsSource = viewData.splinesData.splineDataItems;
                text_integral.Text = string.Format(format, viewData.splinesData.integralValue);
            }
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SplineDataItem? spline_data_item = spline_box.SelectedItem as SplineDataItem;
            string format = "{0:F}";
            if (spline_data_item != null)
            {
                spline_text.Text = spline_data_item.ToString(format);
            }
        }

    }
}
