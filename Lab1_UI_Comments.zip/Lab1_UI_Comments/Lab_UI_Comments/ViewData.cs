﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLibrary;
using System.Windows;
using System.Windows.Shapes;

namespace Lab1_UI_Comments
{
    internal class ViewData
    {
        public double leftEnd { get; set; }
        public double rightEnd { get; set; }
        public int nRawNodes { get; set; }
        public FRaw fRaw { get; set; }  // для способа 2
        public FRawEnum Functions { get; set; }

        public int nGrid { get; set; }
        public double firstDer { get; set; }
        public double secDer { get; set; }
        public double leftDer { get; set; }
        public double rightDer { get; set; }
        public bool gridType { get; set; }
        public double[] RawNodes { get; set; }
        public double[] RawValues { get; set; }
        public string filename { get; set; }
        public bool R_grid { get; set; }
        public bool N_grid { get; set; }
        public List<FRaw> listFRaw { get; set; }  // Способ 2. Список делегатов
        public RawData? rawData;
        public SplineData? splinesData;
        public void Save(string filename)
        {
            try
            {
                rawData.Save(filename);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Load(string filename)
        {
            try
            {
                RawData.Load(filename, out rawData);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка формата данных: " + ex.Message);
            }
        }
        public void ExeSplines_load()
        {
            try
            {

                splinesData = new SplineData(rawData, leftDer, rightDer, nGrid);
                splinesData.DoSplines();
            }
            catch (Exception ex)
            {
                throw new FormatException($"Неправильный формат данных в файле");
            }
        }
        public ViewData()
        {
            this.Functions = FRawEnum.Linear;
            this.leftEnd = 1.5;
            this.rightEnd = 8;
            this.nRawNodes = 5;
            this.leftDer = 2;
            this.rightDer = 8;
            this.nGrid = 20;
            this.R_grid = true;
            this.N_grid = false;
            listFRaw = new List<FRaw>();       // для способа 2
            listFRaw.Add(RawData.Linear);      // для способа 2
            listFRaw.Add(RawData.Randomic);   // для способа 2
            listFRaw.Add(RawData.Cubic); // для способа 2
            fRaw = listFRaw[2];                // для способа 2
        }
        public void ExeSplines()
        {
            try
            {
                switch (Functions)
                {
                    case FRawEnum.Linear:
                        fRaw = RawData.Linear;
                        break;
                    case FRawEnum.Cubic:
                        fRaw = RawData.Cubic;
                        break;
                    default:
                        fRaw = RawData.Randomic;
                        break;
                }
                rawData = new RawData(leftEnd, rightEnd, nRawNodes, gridType, fRaw);
                rawData.RawNodes = new double[nRawNodes];
                rawData.RawValues = new double[nRawNodes];
                if (R_grid)
                {
                    for (int i = 0; i < nRawNodes; i++)
                    {
                        rawData.RawNodes[i] = leftEnd + i * (rightEnd - leftEnd) / (nRawNodes - 1);
                        rawData.RawValues[i] = fRaw(rawData.RawNodes[i]);
                    }
                }
                else
                {
                    for (int i = 0; i < nRawNodes - 1; i++)
                    {
                        if (i % 3 == 0) rawData.RawNodes[i] = leftEnd + i * 0.42 * (rightEnd - leftEnd) / (nRawNodes - 1);
                        else
                        {
                            rawData.RawNodes[i] = leftEnd + i * (rightEnd - leftEnd) / (nRawNodes - 1);
                        }
                    }
                    rawData.RawNodes[nRawNodes - 1] = rightEnd;
                    Array.Sort(rawData.RawNodes);
                    for (int i = 0; i < nRawNodes - 1; i++) rawData.RawValues[i] = fRaw(rawData.RawNodes[i]);

                }
                splinesData = new SplineData(rawData, leftDer, rightDer, nGrid);
                splinesData.DoSplines();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public override string ToString()
        {
            return $"leftEnd = {leftEnd}\n" +
                   $"nRawNodes = {nRawNodes}\n" +
                   $"fRaw = {fRaw.Method.Name}\n";
        }
    }
}
